import React, { useEffect, useState } from "react";
import Button from "../UI/Button/Button";
import Card from "../UI/Card/Card";
import classes from "./CommentSelect.module.css";
import { useSelector, useDispatch } from "react-redux";
import { commentActions} from '../../store/comment-slice';

function Select() {
  const pageNumber = useSelector((state) => state.com.pageNumber);
  const pageLimit = useSelector((state)=> state.com.pageLimit);
  const limiter = useSelector((state)=>state.com.limiter);
  const dispatch = useDispatch();

  const comments = useSelector((state)=>state.com.comments);
  const sp1=useSelector((state)=> state.com.sp1);
  const sp2=useSelector((state)=> state.com.sp2);
  const [nextIsDisable, setNextDisable] = useState(false);
  const [prevIsDisable, setPrevDisable] = useState(false);
  
 
  const[length,setLength]=useState(3);

  

  useEffect(() => {
    // if (pageLimit == pageNumber) {
    //   setNextDisable(true);
    //   setPrevDisable(false);
    // } else {
    //   setPrevDisable(false);
    //   setNextDisable(false);
    // }
    // if (1 == pageNumber) {
    //   setPrevDisable(true);
    //   setNextDisable(false);
    // }

    

  }, [pageNumber]);

 

 

  const nextButtonHandler = () => {
           
         
          
            
            // for(let i=count; i<length; i++){
            //   //  if(i==comments[i]){
            //   //    break;
            //   //  }
            //   dispatch(commentActions.setTempData(comments[i]));
            //    console.log(i)
            // }
            // setCount(count+2);
            // setLength(length+2);
            // console.log(tempData)
            dispatch(commentActions.sp1());
            dispatch(commentActions.sp2());

            console.log(sp1);
            console.log(sp2);
     const tempArray = comments.slice(sp1,  sp2);
   

     console.log(tempArray)
    //  dispatch(commentActions.setLimiter(limiter + 2));
  dispatch(commentActions.setTempData(tempArray));
   // dispatch(commentActions.incrementPageNumber());
    // dispatch(dataActions.incrementPageNum());
    // window.scrollTo({top: 0, left: 0, behavior: 'smooth'});
  };

  const prevButtonOnHandler = () => {
    dispatch(commentActions.desp1());
    dispatch(commentActions.desp2());
    console.log(sp1);
    console.log(sp2);
    const tempArray = comments.slice(sp1,  sp2);
    
    console.log(tempArray)
    

    // const tempArray = comments.slice(limiter-2, limiter - 1);
    // console.log(tempArray)
    // dispatch(commentActions.setLimiter(limiter - 3));
   dispatch(commentActions.setTempData(tempArray));
    // dispatch(commentActions.decrementPageNumber());
    // const tempArray = data.slice(limiter - 20, limiter - 10);
    // console.log(tempArray);
    // dispatch(dataActions.setLimiter(limiter - 10));
    // dispatch(dataActions.setTempData(tempArray));
    // dispatch(dataActions.decrementPageNum());
    // window.scrollTo({top: 0, left: 0, behavior: 'smooth'});
    
  };

  return (
    <Card className={classes.main}>
      <Button
        className={classes.button}
        onClick={prevButtonOnHandler}
        disabled={prevIsDisable}
      >
        Prev
      </Button>
      <span>
        {pageNumber}/{pageLimit}
      </span>
      <Button
        className={classes.button}
        onClick={nextButtonHandler}
        disabled={nextIsDisable}
      >
        next
      </Button>
    </Card>
  );
}
export default Select;
