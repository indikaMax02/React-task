import {createSlice} from '@reduxjs/toolkit';

const commentSlice= createSlice({
    name:'com',
    initialState : {
        comments : [],
        tempData : [],
        length : 0,
        pageNumber : 1,
        pageLimit : 0,
        limiter : 2,
        sp1 : 2,
        sp2 : 4,
    },
    reducers : {

        setComments(state,action){
              state.comments=action.payload;
              state.length=action.payload.length;
              state.pageLimit= Math.round(action.payload.length / 2);
        },
        incrementPageNumber(state){
              state.pageNumber=state.pageNumber+1;       
        },
        decrementPageNumber(state){
            state.pageNumber=state.pageNumber-1;
        },
        setLimiter(state,action){
            state.limiter=action.payload;
        },
        setTempData(state,action){
            state.tempData=action.payload;
       },
    }
});

export const commentActions= commentSlice.actions;
export default commentSlice;
